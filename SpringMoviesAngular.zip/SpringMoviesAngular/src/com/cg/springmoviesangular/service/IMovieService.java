package com.cg.springmoviesangular.service;

import java.util.List;

import com.cg.springmoviesangular.bean.Movie;

public interface IMovieService {

	public List<Movie> getAllMovies();

	public void addMovie(Movie movie);

	public List<Movie> getAllGenreMovies();
}
