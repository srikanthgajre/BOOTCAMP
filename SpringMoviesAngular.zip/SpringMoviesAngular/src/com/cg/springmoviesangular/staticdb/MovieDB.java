package com.cg.springmoviesangular.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.springmoviesangular.bean.Movie;

public class MovieDB {

	private static List<Movie> movieList = new ArrayList<Movie>();

	static {

		movieList.add(new Movie(101, "HomeAlone", 4, "Fiction"));
		movieList.add(new Movie(102, "Avengers", 5, "Fiction"));
		movieList.add(new Movie(103, "NowYouSeeMe", 4, "Drama"));
		movieList.add(new Movie(104, "DieHard", 3, "Fiction"));
		movieList.add(new Movie(105, "Gravity", 4, "Satire"));

	}

	public static List<Movie> getMovieList() {

		return movieList;
	}

	public static void setMovieList(List<Movie> movieList) {

		MovieDB.movieList = movieList;
	}
}
