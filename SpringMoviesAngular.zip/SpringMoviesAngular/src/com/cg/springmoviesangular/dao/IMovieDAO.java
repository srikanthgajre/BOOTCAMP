package com.cg.springmoviesangular.dao;

import java.util.List;

import com.cg.springmoviesangular.bean.Movie;

public interface IMovieDAO {

	public List<Movie> getAllMovies();

	public void addMovie(Movie movie);

	public List<Movie> getAllGenreMovies();
}
