package com.cg.springmoviesangular.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MoviesAngular")
public class Movie {

	@Id
	@Column(name="movie_id")
	private int movieId;
	@Column(name="movie_name")
	private String movieName;
	@Column(name="movie_rating")
	private int movieRating;
	@Column(name="movie_genre")
	private String movieGenre;
	
	public Movie() {
		super();
	}
	
	public Movie(int movieId, String movieName, int movieRating, String movieGenre) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieRating = movieRating;
		this.movieGenre = movieGenre;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getMovieRating() {
		return movieRating;
	}
	public void setMovieRating(int movieRating) {
		this.movieRating = movieRating;
	}
	public String getMovieGenre() {
		return movieGenre;
	}
	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieRating=" + movieRating
				+ ", movieGenre=" + movieGenre + "]";
	}
	
	
}
