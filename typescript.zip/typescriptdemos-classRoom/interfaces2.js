var employees = [
    {
        firstName: "pavan",
        lastName: "kumar",
        age: 23,
        salary: 43000
    },
    {
        firstName: "siva",
        lastName: "krishna",
        age: 33,
        salary: 43000
    }
];
for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
    var emp = employees_1[_i];
    console.log(emp);
}
console.log("==============================================================");
for (var _a = 0, employees_2 = employees; _a < employees_2.length; _a++) {
    var emp = employees_2[_a];
    console.log(emp.age);
}
