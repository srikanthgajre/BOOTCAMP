function call() {
    for (var i = 0; i < 5; i++) {
        console.log("i value is: " + i);
    }
    //console.log("loop ended: " + i) ;
}
call();
