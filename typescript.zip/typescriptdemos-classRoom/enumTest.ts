enum Month{

	january =0,
	feb = 1,
	tues = 2
}

let monthname = Month.feb;
console.log("value of the month is: " + monthname);