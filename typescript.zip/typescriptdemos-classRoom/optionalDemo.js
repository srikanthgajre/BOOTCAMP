function test(one, two, three) {
    if (two === void 0) { two = 5; }
    console.log(one);
    console.log(two);
    console.log(three);
    return one + two + three;
}
var sum = test(10, 20);
console.log("sum is: " + sum);
