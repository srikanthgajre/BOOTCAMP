var Month;
(function (Month) {
    Month[Month["january"] = 0] = "january";
    Month[Month["feb"] = 1] = "feb";
    Month[Month["tues"] = 2] = "tues";
})(Month || (Month = {}));
var monthname = Month.feb;
console.log("value of the month is: " + monthname);
