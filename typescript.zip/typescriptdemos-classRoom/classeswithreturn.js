var EmployeeService = /** @class */ (function () {
    function EmployeeService() {
    }
    return EmployeeService;
}());
var employees = [];
getAllEmployee();
IEmployee[];
{
    employees.push({
        empId: 1001,
        empName: "Rahul",
        empSalary: 5000,
        empDepartment: "JAVA"
    }, {
        empId: 1002,
        empName: "Vikash",
        empSalary: 6000,
        empDepartment: "JAVA"
    }, {
        empId: 1003,
        empName: "Shital",
        empSalary: 7000,
        empDepartment: ".NET"
    });
    return employees;
}
var obj = new EmployeeService();
var employees = obj.getAllEmployee();
for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
    var emp = employees_1[_i];
    console.log(emp);
}
