
let id  = 12;
console.log("id is: " + id);

function mine(){
	console.log("my function");
}

mine();


let ex = () => {
console.log("call");
}
ex();


