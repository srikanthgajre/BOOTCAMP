var Employee = {
    firstName: "pavan",
    lastName: "kumar",
    age: 23,
    salary: 43000
};
console.log("dats is: " + Employee.firstName + "--" + Employee.lastName);
console.log("==============================================================");
var employees = [];
employees.push({
    firstName: "pavan",
    lastName: "kumar",
    age: 23,
    salary: 43000
}, {
    firstName: "siva",
    lastName: "krishna",
    age: 33,
    salary: 43000
}, {
    firstName: "shanthi",
    lastName: "pavan",
    age: 31,
    salary: 53000
});
console.log("dats is: " + employees[0].firstName + "--" + employees[0].lastName);
console.log("dats is: " + employees[1].firstName + "--" + employees[1].salary);
console.log("dats is: " + employees[2].firstName + "--" + employees[2].age);
console.log("==============================================================");
for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
    var emp = employees_1[_i];
    console.log(emp);
}
console.log("==============================================================");
for (var _a = 0, employees_2 = employees; _a < employees_2.length; _a++) {
    var emp = employees_2[_a];
    console.log(emp.age);
}
