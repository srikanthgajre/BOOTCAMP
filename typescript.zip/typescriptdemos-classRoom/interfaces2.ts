interface Person{
	firstName:string;
	lastName:string;
	age:number;
	salary:number;
}

let employees : Person[] = [

{
	firstName : "pavan",
	lastName : "kumar",
	age : 23,
	salary : 43000
},
{
	firstName : "siva",
	lastName : "krishna",
	age : 33,
	salary : 43000
}

];

for(let emp of employees){
	console.log(emp);
}

console.log("==============================================================");
for(let emp of employees){
	console.log(emp.age);
}



