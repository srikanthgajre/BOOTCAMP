function test(one:number,two=5,three?:number) : number{

	console.log(one);
	console.log(two);
	console.log(three);
	return one+two+three;
}

let sum = test(10,20,30);
console.log("sum is: " + sum);