class Animal {
    constructor(public name: string) { 
	}
	
    move(distanceInMeters: number = 0) {
        console.log(`${this.name} moved ${distanceInMeters}ms.`);
    }
}

class Snake extends Animal {
 
	constructor(name: string) { 
		super(name); 
	}
	
    move(distanceInMeters = 5) {
        console.log("Slithering...");
        super.move(distanceInMeters);
    }
}

let snake = new Snake("sending snake object");
snake.move();