interface Person{
	
	firstName:string;
	lastName:string;
	age:number;
	salary:number;
	
}

let Employee : Person={
	
	firstName : "pavan",
	lastName : "kumar",
	age : 23,
	salary : 43000
}

console.log("dats is: " + Employee.firstName + "--" + Employee.lastName);

console.log("==============================================================");


let employees : Person[] = [];

employees.push({
	firstName : "pavan",
	lastName : "kumar",
	age : 23,
	salary : 43000
},
{
	firstName : "siva",
	lastName : "krishna",
	age : 33,
	salary : 43000
},
{
	firstName : "shanthi",
	lastName : "pavan",
	age : 31,
	salary : 53000
},

);

console.log("dats is: " + employees[0].firstName + "--" + employees[0].lastName);
console.log("dats is: " + employees[1].firstName + "--" + employees[1].salary);
console.log("dats is: " + employees[2].firstName + "--" + employees[2].age);
console.log("==============================================================");

for(let emp of employees){
	console.log(emp);
}

console.log("==============================================================");
for(let emp of employees){
	console.log(emp.age);
}



