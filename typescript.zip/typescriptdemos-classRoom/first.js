var id = 12;
console.log("id is: " + id);
