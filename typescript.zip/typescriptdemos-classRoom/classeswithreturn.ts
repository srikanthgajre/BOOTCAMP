interface IEmployee{
    empId:Number,
    empName:String,
    empSalary:number;
    empDepartment:string;
}

class EmployeeService{
	
	let employees : IEmployee[] = [];
	
    getAllEmployee():IEmployee[]{ 
	
		employees.push(
		{ 	
			empId: 1001, 
			empName: "Rahul", 
			empSalary: 5000, 
			empDepartment: "JAVA" 
		},
        { 	
			empId: 1002, 
			empName: "Vikash", 
			empSalary: 6000, 
			empDepartment: "JAVA" 
		},
        
		{ 
			empId: 1003, 
			empName: "Shital", 
			empSalary: 7000, 
			empDepartment: ".NET" 
		}
	);
	
	return employees;
    }
}

let obj = new EmployeeService();
let employees : IEmployee[] = obj.getAllEmployee();

for(let emp of employees){
	console.log(emp);
}
