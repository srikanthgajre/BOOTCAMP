function test(){

for(let i=0;i<5;i++){
	console.log("i value is: "+i);
}
//console.log("final value of i is : " + i);
}

test();