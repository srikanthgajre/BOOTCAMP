import {IProduct} from "./product";
import {company} from "./product";
//Declare Product

let prod: IProduct={
        productId:1001,
       productName:"iPhone"
}
console.log(prod.productId);
console.log(prod.productName);
				
let productArray: IProduct[]=[
                {productId: 1002, productName: "LG"},    
                {productId: 1003, productName: "CoolPad"}, 
                {productId: 1004, productName: "Mi"} ];

for (let pro of productArray) {
    console.log(pro.productId);
    console.log(pro.productName);
}

console.log(company);
