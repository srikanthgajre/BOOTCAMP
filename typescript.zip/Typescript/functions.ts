
function add(n1:number,n2:number) : number{
	return n1+n2;
}
let sum:number = add(12,23);
console.log("sum is: " + sum);

console.log("============================");

function add1(n1:number,n2:number) : void{
	console.log(n1+n2);
}
add1(12,23);
console.log("============================");


function addConcat(n1:string,n2:string) : string{
	let result:string = n1.concat(n2);
	return result;
}
let res:string = addConcat("aaa","bbb");
console.log("concat is: " + res);
console.log("============================");


function sumAll(...num: number[]){
    let sum: number = 0;
    for (let data of num) {
        sum = sum + data;
        console.log("Addition of number " + data);
}
    console.log("Sum is " + sum);  
}

sumAll(6, 7, 8, 9, 5);
console.log("============================");


function doGet(one: number, two = 5, three?: number): void{
    
    console.log(one);
    console.log(two);
    console.log(three);
}

doGet(10,30);





