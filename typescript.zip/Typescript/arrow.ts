let my = () => console.log("test arrow");
my();


let myArg = (a,b) => {
let sum = a+b;
console.log(`sum of ${a} and ${b} is: ${sum}`);
console.log("sum of " + a + " and " + b + " is: " + sum);
return sum;
}

//let myArg = (a:number,b:number) => {
//let sum:number = a+b;
//console.log(`sum of ${a} and ${b} is: ${sum}`);
//console.log("sum of " + a + " and " + b + " is: " + sum);
//return sum;
//}

var add = myArg(12,23);
console.log(add);
