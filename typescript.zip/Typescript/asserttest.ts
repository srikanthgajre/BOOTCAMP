
let str:any = "typescript";
let str2:string = (<string>str);
console.log(str2.substring(2,4));
let str3:string = str as string;
console.log(str3.substring(2,4));