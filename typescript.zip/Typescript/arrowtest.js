var mySum = function (a, b) {
    var sum = a + b;
    console.log("sum of " + a + " and " + b + " is: " + sum);
    console.log("sum of " + a + " and " + b + " is: " + sum);
    return sum;
};
var add = mySum(12, 23);
console.log("sum is: " + add);
