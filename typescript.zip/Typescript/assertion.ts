let str:any = "pavan kumar";

let sub:string = str.substring(2,5);
console.log(sub);

console.log("=============");
console.log("=============");

let str2:string = (<string>str);
console.log(str2);
console.log("=============");

let str3:string = str as string;
console.log(str3);
console.log(str3.substring(2,4));
console.log("=============");


