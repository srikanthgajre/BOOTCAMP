function doGet()
{
   for(var i = 0; i < 5; i++)
   {
      console.log(i);
   }
   console.log("Finally " + i);
}

doGet();

//var s1 = '2';
//var s2:number = <number> <any> s1;
//var sum = s1+s2;
//console.log(sum);
//console.log(s2+s2);

// let works only inside loop, can't access the variables outside of loop
