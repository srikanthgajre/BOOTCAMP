let id:number=900;
console.log(`id is : ${id}`);
console.log("============");

let arr:string[] = ["a","b"];
for(let name of arr){
console.log(name);
}
console.log("============");

for(let i=0;i<arr.length;i++){
console.log(`name is: ${arr[i]}`);
}
console.log("============");

const salary = 780000;
console.log(salary);
//salary = 90000;
console.log("============");

enum colors{
red = 0,
white = 1
}
var colorname = colors.white;
console.log("name is:" + colorname); 
console.log("============");


