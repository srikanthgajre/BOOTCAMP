constant message = "say Hi";
//message = "say Hello instead";
console.log(message);