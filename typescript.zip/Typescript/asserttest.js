var str = "typescript";
var str2 = str;
console.log(str2.substring(2, 4));
var str3 = str;
console.log(str3.substring(2, 4));
