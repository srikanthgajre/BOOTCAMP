package com.cg.dao;

import java.util.List;

import com.cg.entities.Recharge;

public interface RechargeRepository {

	void addRecharge(Recharge recharge);

	 public abstract List<Recharge> loadAll();

	 public abstract Recharge getTransaction(long rechargeId);

}
