package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entities.Recharge;

@Repository
public class RechargeRepositoryImp implements RechargeRepository {
	@PersistenceContext
    private EntityManager entityManager;
	@Override
	public void addRecharge(Recharge recharge) {
		entityManager.persist(recharge);
		entityManager.flush();
		
	}
	@Override
	public List<Recharge> loadAll() {
		TypedQuery<Recharge> query= entityManager.createQuery("Select r from Recharge r",Recharge.class);
		return query.getResultList();
		
	}
	@Override
	public Recharge getTransaction(long rechargeId) {
		Recharge recharge=entityManager.find(Recharge.class, rechargeId);
		return recharge;
	}

}
