package com.cg.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cg.entities.Recharge;

import com.cg.service.RechargeService;

@Controller
public class RechargeController {
	@Autowired
	RechargeService rechargeService;
	
	@RequestMapping("/index")
	public String getHomepage(Model model) {
	model.addAttribute("recharge",new Recharge());
		return "index";
	}
	@RequestMapping(value="/recharge")
	public String recharge(Model model,Recharge recharge) {
		model.addAttribute("plans",new String[]{"RC-349","RC-199","RC-599","RC-1100"});
		model.addAttribute("recharge",recharge);
		return "recharge";
	}
	
	
	@RequestMapping(value="/rechargesuccess")
	public String rechargesuccess(@ModelAttribute("recharge")Recharge recharge,Model model) {
		recharge.setRechargeDate(LocalDate.now());
	
		String plan=recharge.getPlan();
	   if(plan.equalsIgnoreCase("RC-349"))
		   recharge.setRechargeAmount(349);
	   else if(plan.equalsIgnoreCase("RC-199"))
		   recharge.setRechargeAmount(199);
	   else if(plan.equalsIgnoreCase("RC-599"))
		   recharge.setRechargeAmount(599);
	   else if(plan.equalsIgnoreCase("RC-1100"))
		   recharge.setRechargeAmount(1100);
	   else 
		   recharge.setRechargeAmount(1000);
	   System.out.println(recharge);
		model.addAttribute("message","Recharge with Plan"+recharge.getRechargeAmount()+"is done succesfully!");
		
		rechargeService.addRecharge(recharge);
		return "redirect:/index.html";
	}
	

	@RequestMapping("/allTransactions")
	public String allTransactions(@ModelAttribute("recharge")Recharge recharge,Model model) {
		model.addAttribute(recharge);
		model.addAttribute("transactions",rechargeService.loadAll());
	
		return "allTransactions";
	}
	@RequestMapping(value="/search")
	public String search(Model model,Recharge recharge) {
		model.addAttribute("recharge",recharge);
		return "search";
	}
	@RequestMapping(value="/getResult")
	public String searchnow(@ModelAttribute("recharge")Recharge recharge,Model model) {
		//System.out.println(recharge.getRechargeId());
		Recharge recharge1=rechargeService.getTransaction(recharge.getRechargeId());
		model.addAttribute("recharge1",recharge1);
		System.out.println(recharge1);
		model.addAttribute("message1","Hello "+recharge1.getCustomerName()+" your Transaction with Id : "+recharge1.getRechargeId()+"  is found !!!");
		return "getResult";
	}
	
	
	
}
