package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.RechargeRepository;
import com.cg.entities.Recharge;
@Service
@Transactional
public class RechargeServiceImp implements RechargeService {
    @Autowired
	RechargeRepository rechargeRepository;
    
	@Override
	public void addRecharge(Recharge recharge) {
		rechargeRepository.addRecharge(recharge);
	}

	@Override
	public List<Recharge> loadAll() {
		
		return rechargeRepository.loadAll();
	}

	@Override
	public Recharge getTransaction(long rechargeId) {
		
		return rechargeRepository.getTransaction(rechargeId);
	}

}
