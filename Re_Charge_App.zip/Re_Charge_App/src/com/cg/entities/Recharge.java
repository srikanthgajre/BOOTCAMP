package com.cg.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Recharge implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long rechargeId;
private String customerName;
private String mobileNumber;
private String serviceProvider;
private String plan;

private double rechargeAmount;
private LocalDate rechargeDate;
private String description;
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public long getRechargeId() {
	return rechargeId;
}
public void setRechargeId(long rechargerId) {
	this.rechargeId = rechargerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getServiceProvider() {
	return serviceProvider;
}
public void setServiceProvider(String serviceProvider) {
	this.serviceProvider = serviceProvider;
}
public double getRechargeAmount() {
	return rechargeAmount;
}
public void setRechargeAmount(double rechargeAmount) {
	this.rechargeAmount = rechargeAmount;
}
public LocalDate getRechargeDate() {
	return rechargeDate;
}
public void setRechargeDate(LocalDate rechargeDate) {
	this.rechargeDate = rechargeDate;
}
public String getPlan() {
	return plan;
}
public void setPlan(String plan) {
	this.plan = plan;
}

@Override
public String toString() {
	return "\nTransactionId=: " + rechargeId + " \n customerName:" + customerName + "\n mobileNumber:"
			+ mobileNumber + "\n serviceProvider: " + serviceProvider + "\n plan:" + plan + "\n rechargeAmount:"
			+ rechargeAmount + "\n rechargeDate:" + rechargeDate + "\n description:" + description + "";
}
public Recharge(long rechargerId, String customerName, String mobileNumber, String serviceProvider, String plan,
		double rechargeAmount, LocalDate rechargeDate, String description) {
	super();
	this.rechargeId = rechargerId;
	this.customerName = customerName;
	this.mobileNumber = mobileNumber;
	this.serviceProvider = serviceProvider;
	this.plan = plan;
	this.rechargeAmount = rechargeAmount;
	this.rechargeDate = rechargeDate;
	this.description = description;
}
public Recharge() {
	super();
}


}
