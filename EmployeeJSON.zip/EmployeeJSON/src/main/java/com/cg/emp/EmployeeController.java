package com.cg.emp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
    @RequestMapping("all")
	public List<Employee> getall() {
		List<Employee> employees =new ArrayList();
		Employee e1=new Employee();
		e1.setEmpId(14);
		e1.setEmpName("Srikanth");
		e1.setMobileNumber("8008809987");
		Employee e2=new Employee();
		e2.setEmpId(59);
		e2.setEmpName("RAM");
		e2.setMobileNumber("9573390993");
		employees.add(e1);
		employees.add(e2);
		return employees;
		
	}
}
