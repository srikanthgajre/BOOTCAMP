package com.cg.emp;

public class Employee {

	private String empName;
	private int empId;
	private String mobileNumber;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Employee(String empName, int empId, String mobileNumber) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.mobileNumber = mobileNumber;
	}
	public Employee() {
		super();
	}
	
	
}
